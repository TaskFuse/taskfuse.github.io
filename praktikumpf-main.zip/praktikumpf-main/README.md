Praktikumpf

Für das Starten des Projekts wird Node.js mit NPM benötigt.
Node.js v16.14.2 (LTS geht auch)

Für die erste Ausführung:
```
npm install
npm run installDep
```

Danach:
```
npm start
```
